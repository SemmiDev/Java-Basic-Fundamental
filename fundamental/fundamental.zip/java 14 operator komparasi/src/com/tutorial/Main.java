package com.tutorial;

public class Main{
	public static void main(String[] args) {
		int a;
		int b;
		boolean hasilKomparasi;

		System.out.println("==================== OPERATOR KOMPARASI ====================\n");
		// persamaan / equal
		a = 10;
		b = 12;
		hasilKomparasi = (a == b);
		System.out.println("----------> PERSAMAAN dan PERTIDAKSAMAAN <----------");
		System.out.printf("%d == %d --> %s \n",a,b,hasilKomparasi);

		// pertidaksamaan / not equal
		a = 10;
		b = 12;
		hasilKomparasi = (a != b);
		System.out.printf("%d != %d --> %s \n",a,b,hasilKomparasi);



		// kurang dari / less than
		a = 10;
		b = 12;
		hasilKomparasi = (a < b);
		System.out.println("----------> KURANG DARI dan LEBIH DARI <----------");
		System.out.printf("%d < %d --> %s \n",a,b,hasilKomparasi);
		// lebih dari / greater than
		a = 10;
		b = 12;
		hasilKomparasi = (a > b);
		System.out.printf("%d > %d --> %s \n",a,b,hasilKomparasi);


		// lebih dari / less than equal
		a = 10;
		b = 12;
		hasilKomparasi = (a <= b);
		System.out.println("----------> KURANG atau SAMA DARI dan EBIH atau SAMA DARI <----------");
		System.out.printf("%d <= %d --> %s \n",a,b,hasilKomparasi);
		
		// lebih dari / greater than equal
		a = 10;
		b = 12;
		hasilKomparasi = (a >= b);

		System.out.printf("%d >= %d --> %s \n",a,b,hasilKomparasi);





	}
}