package com.program;

public class Main {
	public static void main(String[] args) {
		int x = 20;
		int y = 4;
		int hasil;

		// penjumlahan
		hasil = x + y;
		System.out.println(x + " + " + y + " = " + hasil);
		System.out.printf("%d + %d = %d\n",x,y,hasil);

		// pengurangan
		hasil = x - y;
		System.out.println(x + " - " + y + " = " + hasil);

		// perkalian
		hasil = x * y;
		System.out.println(x + " * " + y + " = " + hasil);

		// pembagian
		hasil = x / y;
		System.out.println(x + " / " + y + " = " + hasil);

		// modulus 
		hasil = x % y;
		System.out.println(x + " % " + y + " = " + hasil);

		double a = 3.4;
		double b = 8.8;
		double hhasil = a / b ;
		System.out.println(a + " / " + b + " = " + hhasil);






	}
}