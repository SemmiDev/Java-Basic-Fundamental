package com.tutorial;
import java.util.Scanner;

public class Main{
	public static void main(String[] args) {
		// pembagian dan perkalian akan dieksekusi terlebih dahulu kemudian baru operasi penjumlahan dan pengurangan.
		// pengelompokkan > perkalian/pembagian > penjumlahan dan pengurangan

		// int hasil = 5 + 4 * 10 / 3 + (5 + 4);
		// System.out.println("hasil dari 5 + - 4 * 10 / 3 + (5 + 4) =  " + hasil);

		Scanner userInput = new Scanner(System.in);
		// perhitungan persaman kuadrat
		System.out.println("MENGHITUNG PERSAMAAN KUADRAT");
		int m,x,c;
		System.out.print("nilai x = ");
		x = userInput.nextInt();
		System.out.print("nilai m = ");
		m = userInput.nextInt();
		System.out.print("nilai x = ");
		c = userInput.nextInt();
		int y = m + x + x + c;

		System.out.print("hasilnya adalah = " + y);

	}
}