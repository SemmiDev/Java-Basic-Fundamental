package com.program;

public class Main {
	public static void main(String[] args) {
		// integer
		int a = 10;
		System.out.println("=========INTEGER=========");
		System.out.println("Nilai dari integer a = " + a);
		System.out.println("Nilai maksimal dari integer = " + Integer.MAX_VALUE);
		System.out.println("Nilai minimal dari integer = " + Integer.MIN_VALUE);
		System.out.println("Besar memori integer = " + Integer.BYTES + " byte");
		System.out.println("Nilai memori integer = " + Integer.SIZE + " bi \n");

		// byte
		byte b = 10;
		System.out.println("=========BYTE=========");
		System.out.println("Nilai dari byte b = " + b);
		System.out.println("Nilai maksimal dari byte = " + Byte.MAX_VALUE);
		System.out.println("Nilai minimal dari byte = " + Byte.MIN_VALUE);
		System.out.println("Besar memori byte = " + Byte.BYTES + " byte");
		System.out.println("Nilai memori byte = " + Byte.SIZE + " bit \n");

		// short
		short s = 10;
		System.out.println("=========SHORT=========");
		System.out.println("Nilai dari short s = " + s);
		System.out.println("Nilai maksimal dari short = " + Short.MAX_VALUE);
		System.out.println("Nilai minimal dari short = " + Short.MIN_VALUE);
		System.out.println("Besar memori short = " + Short.BYTES + " byte");
		System.out.println("Nilai memori short = " + Short.SIZE + " bit \n");

		// long
		long l = 10L; // L sebagai tanda long saja | tidak ada juga tidak apa2
		System.out.println("=========LONG=========");
		System.out.println("Nilai dari long l = " + l);
		System.out.println("Nilai maksimal dari Long = " + Long.MAX_VALUE);
		System.out.println("Nilai minimal dari Long = " + Long.MIN_VALUE);
		System.out.println("Besar memori Long = " + Long.BYTES + " byte");
		System.out.println("Nilai memori Long = " + Long.SIZE + " bit \n");

		// double
		double d = 10.3d; // bil real | d sebagai penanda | berkoma-koma
		System.out.println("==========DOUBLE=========");
		System.out.println("Nilai dari Double d = " + d);
		System.out.println("Nilai maksimal dari Double = " + Double.MAX_VALUE);
		System.out.println("Nilai minimal dari Double = " + Double.MIN_VALUE);
		System.out.println("Besar memori Double = " + Double.BYTES + " byte");
		System.out.println("Nilai memori Double = " + Double.SIZE + " bit \n");

		// float
		float f = 10.5f; // berkoma-koma
		System.out.println("==========FLOAT==========");
		System.out.println("Nilai dari Float f = " + f);
		System.out.println("Nilai maksimal dari Float = " + Float.MAX_VALUE);
		System.out.println("Nilai minimal dari Float = " + Float.MIN_VALUE);
		System.out.println("Besar memori Float = " + Float.BYTES + " byte");
		System.out.println("Nilai memori Float = " + Float.SIZE + " bit \n");

		// char
		char c = 'x';
		System.out.println("==========CHAR==========");
		System.out.println("Nilai dari char c = " + c);
		System.out.println("Besar memori Character = " + Character.BYTES + " byte");
		System.out.println("Nilai memori Character = " + Character.SIZE + " bit \n");
		
		// boolean
		boolean bool = true; // true / false
		System.out.println("==========BOOLEAN========== \n ========== besar boolean itu adalah 1 bit ==========");
		System.out.println("Nilai dari Float b = " + bool);

	}
}