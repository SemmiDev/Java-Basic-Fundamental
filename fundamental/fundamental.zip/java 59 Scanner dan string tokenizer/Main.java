// package com.tutorial;

import java.util.*;
import java.io.*;

public class Main {
	public static void main(String[] args) throws IOException{
		FileReader fileInput = new FileReader("input.txt");
		BufferedReader bufferedReader = new BufferedReader(fileInput);

		Scanner scanner = new Scanner(bufferedReader);

		// this is for check there next word or not
		while(scanner.hasNext()) {
			System.out.println(scanner.next());
		}

		// menggunakan delimeter tertentu
		FileReader fileInput2 = new FileReader("input2.txt");
		bufferedReader = new BufferedReader(fileInput2);
		bufferedReader.mark(200);

		scanner = new Scanner(bufferedReader);
		scanner.useDelimiter(",");

		while(scanner.hasNext()) {
			System.out.println(scanner.next());
		}


		// menggunakan String Tokenizer

		bufferedReader.reset();
		String data = bufferedReader.readLine();
		System.out.println(data);

		StringTokenizer stringToken = new StringTokenizer(data,",");
		while(stringToken.hasMoreTokens()) {
			System.out.println(stringToken.nextToken());
		}

		// baris kedua
		data = bufferedReader.readLine();
		System.out.println(data);
		stringToken = new StringTokenizer(data,",");
		while(stringToken.hasMoreTokens()) {
			System.out.println(stringToken.nextToken());
		}


	}
}