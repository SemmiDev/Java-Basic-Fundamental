package com.program;

public class Main {
	public static void main(String[] args) {
		// ditambah string di ujung ketika compile (index)
		System.out.print("Hello, " + args[0] + "\n");
		System.out.print(args[1] + " " + args[2] + " di Mobile Development \n");
	}
}