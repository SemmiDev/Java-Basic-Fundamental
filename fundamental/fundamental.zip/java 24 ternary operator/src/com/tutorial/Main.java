package com.tutorial;
import java.util.*;

public class Main{
	public static void main(String[] args) {
		int x,hasil;
		Scanner input = new Scanner(System.in);

		System.out.print("Masukkan Angka : ");
		hasil = input.nextInt();

		x = (hasil == 10) ? (hasil * hasil) : (hasil / hasil);
		System.out.print(x); 
	}
}