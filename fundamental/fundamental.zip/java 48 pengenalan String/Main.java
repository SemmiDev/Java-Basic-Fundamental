// package com.tutorial;
import java.util.*;

public class Main{
	public static void main(String[] args) {

		// membuat string
		String kataString = "Hallo SamDev";
		char[] kataChar = {'H','a','l','l','o'};

		// menampilkan string

		System.out.println(kataString);
		System.out.println(Arrays.toString(kataChar));

		// mengakses komponen/huruf dari dari string

		System.out.println("komponen pertama dari char[] = " + kataChar[3]);
		System.out.println("komponen pertama dari String = " + kataString.charAt(3));

	// merubah kommponen dari string = itu tidak bisa karean string di dalam java bersifat immutable
	// mengubah isi char
	kataChar[0] = 'l';
	System.out.println(Arrays.toString(kataChar));

	// kita bisa mengubahnya secara tidak langsung
	printAddress("kataString sebelum di ubah ",kataString);

	kataString = "c" + kataString.substring(1,4);
	System.out.println("=> " + kataString);
	printAddress("kataString sesudah di ubah ",kataString);
	
		// memory dari string
		String str_1 = "test";
		String str_2 = "test";
		String str_3 = "testing";
		str_3 = str_3.substring(0,4);
		printAddress("str_3 || ", str_3);

		String str_4 = "call";
		printAddress("alamat callo|| ", str_4);



		printAddress("ini adalah alamat str 1 || ", str_1);
		printAddress("ini adalah alamat str 2 || ", str_2);
		printAddress("ini adalah alamat str 3 || ", str_3);
		// string di java itu immutable
		// string yagn berada di sting pool itu akan reusable,sehingga penggunaan memory yg optimal
		// membuat string method baru,maka dia akan ditaro di memory lain, bukan di string pool

		




	}

	private static void printAddress(String data) {
		int address = System.identityHashCode(data);
		System.out.println(Integer.toHexString(address));

	}
}