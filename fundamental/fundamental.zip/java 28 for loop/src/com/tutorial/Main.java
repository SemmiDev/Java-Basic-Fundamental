package com.tutorial;

public class Main{
	public static void main(String[] args) {
		// model 1
		for(int i = 0; i <= 10; i++) {
			System.out.println("Ini angka yang ke- " + i);
		}

		// model 2
		for(int i = 10; i >= 5 ; i--) {
			System.out.println("Ini angka yang ke- " + i);
		}

	}
}