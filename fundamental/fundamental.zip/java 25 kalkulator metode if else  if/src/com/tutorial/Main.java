package com.tutorial;
import java.util.*;

public class Main{
	public static void main(String[] args) {

		Scanner inputUser;
		float x,y,hasil;
		char operator;
		inputUser = new Scanner(System.in);

		System.out.println("Selamat Datang di Program Kalkulator Sederhana");
		System.out.print("Masukkan Angka Pertama : ");
		x = inputUser.nextFloat();
		System.out.print("Masukkan Operator : ");
		operator = inputUser.next().charAt(0);
		System.out.print("Masukkan Angka Kedua : ");
		y = inputUser.nextFloat();

		if(operator == '+'){
			hasil = x + y;
			System.out.println("hasil dari " + x + " + " + y + " = " + hasil);
		} else if(operator == '-'){
			hasil = x - y;
			System.out.println("hasil dari " + x + " - " + y + " = " + hasil);
		} else if(operator == '*'){
			hasil = x * y;
			System.out.println("hasil dari " + x + " x " + y + " = " + hasil);
		} else if(operator == '/'){
			
			if(y == 0) {
				System.out.println("pembagi 0 akan menghasilkan nilai tak hingga / infinity");
			}else {
				hasil = x / y;
			System.out.println("hasil dari " + x + " : " + y + " = " + hasil);
			}

		} else {
			System.out.println("Anda memasukkan operator yang salah");
		}

	}
}