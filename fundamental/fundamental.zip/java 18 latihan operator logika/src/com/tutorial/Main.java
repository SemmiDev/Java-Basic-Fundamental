package com.tutorial;
import java.util.*;

public class Main{
	public static void main(String[] args) {
		// membuat sebuah objek untuk menangkap inputan dari user
		Scanner inputUser = new Scanner(System.in);

		// sebuah program sederhana untuk menebak angka
		int nilaiBenar = 7;
		int nilaiTebakan;
		boolean statusTebakan;

		System.out.print("Masukkan Nilai Tebakan Anda : ");
		nilaiTebakan = inputUser.nextInt();
		System.out.println("Nilai tebakan anda adalah : " + nilaiTebakan);

		// operasi logika
		statusTebakan = (nilaiTebakan == nilaiBenar);
		System.out.println("Tebakan anda : " + statusTebakan);

		// operasi alajabar boolean (and dan or)
		System.out.print("Masukkan nilai antara 5 dan 15 : ");
		nilaiTebakan = inputUser.nextInt();

		statusTebakan = (nilaiTebakan > 5) && (nilaiTebakan < 15);
		System.out.println("Tebakan anda : " + statusTebakan);


	}
}