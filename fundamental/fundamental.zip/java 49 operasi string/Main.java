// package com.tutorial;

import java.util.Scanner;
import java.lang.String;

public class Main{
	public static void main(String[] args) {
		String kalimat = "saya suka makan pisang";

		// mengambil komponen dari string
		System.out.println(kalimat.charAt(5));

		// substring
		String kata = kalimat.substring(10,15);
		System.out.println(kata);

		// concateantion (concat)
		String kalimat2 = kata + " bakwan";
		System.out.println(kalimat2);

		kata = kata + " tempe";
		System.out.println(kata);

		// concat dengan non string
		int jumlah = 20;
		String kalimat3 = kata + " " + jumlah; // casting int ke tipe data string
		System.out.println(kalimat3);

		// lower case dan uppercase , kita akan membuat di memory baru
		System.out.println(kalimat.toUpperCase()); // besar semua
		System.out.println(kalimat.toLowerCase()); // kecil semua

		// replace , contoh : kita akan membuat di memory baru
		String kalimat4 = kalimat.replace("pisang","jeruk");
		System.out.println(kalimat);
		System.out.println(kalimat4);



		// komparasi
		String motor1 = "royal enfield himalayan";
		String motor2 = "kawasaki w175";
		System.out.println(motor1.compareTo(motor2));

		String bahasa1 = "javamobile";
		String bahasa2 = "javascript";
		System.out.println(bahasa1.compareTo(bahasa2));
		System.out.println(bahasa2.compareTo(bahasa1));




		// equality = persamaan
		// String kataInput = "text"; // ini ada di string pool
		String kataInput = new String("test"); // ini bukan string literal maka alokasi memory akan digunakan di string pool
		String kataTest = "test"; // ini di string pool

		// kalau sama-sama string berjenis literak dan value nya sama maka hasillnya akan "sama / equal" kalau beda pool maka akan "tidak sama"
		// ini membandingkan address nya
		if(kataInput == kataTest){
			System.out.println("Sama");
		}else {
			System.out.println("tidak sama");
		}


		Scanner userInput = new Scanner(System.in);
		System.out.print("mengambil string dari user : ");
		kataInput = userInput.next();
		
		System.out.println("ini adalah input user : " + kataInput + "\n");
		if(kataInput.equals(kataTest)){
			System.out.println("Sama");
		}else {
			System.out.println("tidak sama");
		}

		

	}
		private static void printAddress(String data) {
		int address = System.identityHashCode(data);
		System.out.println(Integer.toHexString(address));

	}
}