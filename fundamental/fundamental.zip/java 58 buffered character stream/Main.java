// package com.tutorial;

import java.io.*;
import java.util.Arrays;


public class Main {
	public static void main(String[] args) throws IOException{
		
		// the first step, we will read data
		FileReader fileInput = new FileReader("input.txt");
		BufferedReader bufferedReader = new BufferedReader(fileInput);
		bufferedReader.mark(200);

		// read the data into the string
		String data = bufferedReader.readLine();
		System.out.println(data); 

		// read into char
		bufferedReader.reset();
		char[] dataChar = new char[25];
		bufferedReader.read(dataChar,0,25);
		System.out.println(Arrays.toString(dataChar));

		// read line
		bufferedReader.reset();
		System.out.println(bufferedReader.readLine());
		System.out.println(bufferedReader.readLine());


		// file writing
		FileWritter	fileOutput = new FileWritter("output.txt");
		BufferedWriter bufferedWriter = new BufferedWriter(fileOutput);

		bufferedReader.reset();
		String baris1 = bufferedReader.readLine();
		bufferedWriter.write(baris1,0,baris1.length());
		bufferedReader.flush();


		// menambah enter / new line;
		bufferedWriter.newLine();

		String baris2 = bufferedReader.readLine();
		bufferedWritter.write(baris2,0,baris2.length());
		bufferedWritter.flush();


	}
}