package com.program;

public class Main {
	public static void main(String[] args) {
		// operator unary
		// mengubah operator semula, misal inisialisasi suatu veriable dengan angka positif, jika diunary jadi -namaVariable , maka akan jadi -inisialisasi
		// jika positif di unary  menjadi positif maka akan tetap positif nilainya
		int a = 1;
		System.out.printf("unary '+', %d . menjadi angka %d\n",a, +a);
		System.out.printf("unary '-', %d . menjadi angka %d\n\n\n",a, -a);


		// increment and decrement
		int angka1 = 10;
		angka1++;
		System.out.printf("hasil decrement menjadi = %d \n",angka1);

		int angka2 = 10;
		angka2--;
		System.out.printf("hasil increment menjadi = %d \n\n",angka2);

		// prefix and postfix
		int angka3 = 5;
		System.out.printf("hasil prefix menjadi = %d \n", ++angka3); // akan jadi angka 6
		int angka4 = 20;
		System.out.printf("hasil prefix menjadi = %d \n", angka4++);
		System.out.printf("hasil prefix menjadi = %d \n", angka4);



	}
}