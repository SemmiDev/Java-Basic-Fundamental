package com.tutorial;
import java.util.*;

public class Main{
	public static void main(String[] args) {
		Scanner inputUser;
		inputUser = new Scanner(System.in);
		int nilaiAwal, nilaiAkhir, total;
		
		System.out.print("Masukkan angka awal : ");
		nilaiAwal = inputUser.nextInt();
		System.out.print("Masukkan angka akhir : ");
		nilaiAkhir = inputUser.nextInt();

		// total = 0;
		// while(nilaiAwal <= nilaiAkhir) {
		// 	total = total + nilaiAwal;
		// 	System.out.println("ditambah " + nilaiAwal + " menjadi " + total);
		// 	nilaiAwal++;
		// }
		
		// tugas saya | membuat model for loop dan do while // penjumlahan
		// total = 0;
		// for(int a = nilaiAwal; a <= nilaiAkhir; a++) {
		// 	total = total + a;
		// 	System.out.println("ditambah " + a + " menjadi " + total);
		// }

		// pengurangan
		// total = 0;
		// for(int a = nilaiAkhir; a >= nilaiAwal; a--) {
		// 	total = total - a;
		// 	System.out.println("dikurang " + a + " menjadi " + total);
		// }

		total = 0;
		do {
			total = total + nilaiAwal;
			System.out.println("ditambah " + nilaiAwal + " menjadi " + total);
			nilaiAwal++;
			
		}while(nilaiAwal <= nilaiAkhir);




	}
}