package com.tutorial;

public class Main {
	public static void main(String[] args) {
		// operator bitwise --> operator untuk melakukan operasi pada nilai bit
		byte a = 0;
		String a_bits;

		a_bits = String.format("%8s",Integer.toBinaryString(a)).replace(oldChar: ' ',newChar: '0');
		System.out.printf("%s = %d\n",a_bits,a);
	}
}