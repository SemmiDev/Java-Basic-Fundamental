// package com.tutorial;
import java.util.Arrays;
import java.util.*;


public class Main{
	public static void main(String[] args) {
		// array 2D dengan assignment
		int[][] array_2D = {
				{1,2,3,4,5},
				{5,4,3,2,1}
		};
		printArray2D(array_2D);

		// array 2D dengan deklarasi
		// [baris][kolom]
		int[][] array_2D2 = new int[5][4];
		printArray2D(array_2D2);

System.out.println("\n");

		// looping lengkap dengan cara manual
		for(int i = 0; i < array_2D2.length; i++) {
			System.out.print("[ ");
			for(int j = 0; j < array_2D2[i].length; j++) {
				System.out.print(array_2D2[i][j] + ",");
			}
			System.out.print(" ]\n");
		}

		int[][] coba = {
			{1,2,3,4,5},
			{6,7,8,9,9,10},
			{11,12,13,14,15},
			{16,17,18,19,20},
			{21,22,23,24,25}
		};
		printArray2D(coba);

System.out.println("\n");
	
	}

	public static void printArray2D(int[][] array2D) {
		// System.out.println(Arrays.deepToString(array2D));

		// for(int i = 0; i < array2D.length; i++) {
		// 	System.out.println(Arrays.toString(array2D[i]));

		for(int[] baris : array2D) {
			System.out.print("[ ");
			for(int kolom : baris) {
				System.out.print(kolom + ",");
			}
			System.out.print(" ]\n");
		}

	}
}