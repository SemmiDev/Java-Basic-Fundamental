package com.tutorial;
import java.util.*;

public class Main{
	public static void main(String[] args) {
		Scanner userInput = new Scanner(System.in);
		String nama;
		System.out.print("Masukkan Nama : ");
		nama = userInput.next(); // kalau inputan berupa string maka cukup ditulis next() aja.

		switch(nama) {
			case "sam":
			System.out.print("Hello Sam, Welcome!");
			break;

			case "dev":
			System.out.print("Hello Dev, Welcome!");
			break;

			case "SamDev":
			System.out.print("Hello SamDev, Welcome!");
			break;

			default:
			System.out.print("nama anda tidak teraftar di database");
		}

	}
}