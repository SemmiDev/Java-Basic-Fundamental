package com.program;

public class Main {
	public static void main(String[] args) {
		// variable
		// tipe data

		int x = 10; // assignment
		int y = 5;

		System.out.println("Nilai x = " + x);
		System.out.println("Nilai y = " + y);

		x = 25;
		y = 20;

		System.out.println("Nilai x yang baru = " + x);
		System.out.println("Nilai x yang baru = " + y);

		// deklarasi
		int a;
		a = 555;
		System.out.println("Warning!!! = " + a);

		

	}
}