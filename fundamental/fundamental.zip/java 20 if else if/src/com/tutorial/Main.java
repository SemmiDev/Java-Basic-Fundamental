package com.tutorial;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		
		Scanner inputUser = new Scanner(System.in);
		int user, user1, pass1, user2, pass2, user3, pass3;

		int dataUser1 = 123;
		int dataPass1 = 111;

		int dataUser2 = 1234;
		int dataPass2 = 1111;

		int dataUser3 = 12345;
		int dataPass3 = 11111;


		System.out.println("===== |PILIH ANGKA USER DIBWAWAH INI UNTUK LOGIN| =====");
		System.out.println("1. user A | 2. user B | 3. user C");
		System.out.print("Masuk sebagai user angka : ");
		user = inputUser.nextInt();

		if(user == 1){
			System.out.print("input your username : ");
			user1 = inputUser.nextInt();
			System.out.print("input your password : ");
			pass1 = inputUser.nextInt();

				if(user1 == dataUser1 && pass1 == dataPass1) {
					System.out.print("WELCOME USER A, ANDA BERHASIL LOGIN");
				}else {
					System.out.print("USERNAME DAN PASSWORD ANDA SALAH!");
				}

		}else if(user == 2){
			System.out.print("input your username : ");
			user2 = inputUser.nextInt();
			System.out.print("input your password : ");
			pass2 = inputUser.nextInt();

				if(user2 == dataUser2 && pass2 == dataPass2) {
					System.out.print("WELCOME USER B, ANDA BERHASIL LOGIN");
				}else {
					System.out.print("USERNAME DAN PASSWORD ANDA SALAH!");
				}
		}else if(user == 3){
			System.out.print("input your username : ");
			user3 = inputUser.nextInt();
			System.out.print("input your password : ");
			pass3 = inputUser.nextInt();

				if(user3 == dataUser3 && pass3 == dataPass3) {
					System.out.print("WELCOME USER C, ANDA BERHASIL LOGIN");
				}else {
					System.out.print("USERNAME DAN PASSWORD ANDA SALAH!");
				}
		}else {
			System.out.print("HARAP MASUKKAN SESUAI DENGAN PERMINTAAN");
		}

	}
}