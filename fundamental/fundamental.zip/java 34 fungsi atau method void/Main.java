public class Main{
	public static void main(String[] args) {
		System.out.println(simple());

		for(int i = 1; i <= 10; i++) {
		fungsiVoid(i + "Hello");
		}

		greeting("SamDev");

	}

	//fungsi void tanpa kembalian
	private static void fungsiVoid(String input) {
		System.out.println(input);
	}

	private static void greeting(String nama) {
		System.out.println("selamat pagi" + nama + ", Have a nice day");
	}k





	// fungsi dengan kembalian
	// sehingga menggunakan return untuk mengembalikan nilianya
	private static float simple() {
		return 10.2f;
	}
}