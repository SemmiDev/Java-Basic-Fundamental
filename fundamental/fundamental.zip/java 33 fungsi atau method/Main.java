import java.util.*;

public class Main{
	public static void main(String[] args) {
		Scanner userInput = new Scanner(System.in);
		int a, b;
		System.out.print("Masukkan angka pertama : ");
		a = userInput.nextInt();
		b = jumlah(a);
		System.out.print("hasil dari " + a + " adalah = " + b);

		}

		static int jumlah(int input) {
			int rumus;
			rumus = (input + 2) * input;
			return rumus;
		}

	
}