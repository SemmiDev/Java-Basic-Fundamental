package com.program;

public class Main {
	public static void main(String[] args) {
		// program conversi data
		int nilaiInt = 450;
		System.out.println("Nilai int adalah = " + nilaiInt);

		// memperluas rentang ke tipe data yang lebih besar
		long nilaiLong = nilaiInt;
		System.out.println("Nilai long adalah = " + nilaiLong);

		// memperkecil rentang ke tipe data yang lebih kecil 
		// nilai nya nanti akan ngacok, jika lebih dari nlai max nya.
		// contoh kita coversi ke byte, nilai max byte = 127, angka kita 450.aka rancu jadinya
		byte nilaiByte = (byte) nilaiInt;
		System.out.println("Nilai byte adalah = " + nilaiByte);


		// casting pembagian
		int a = 10;
		int b = 4;
		int c = a / b;
		System.out.printf("%d / %d = %d \n\n\n",a,b,c); // hasilnya akan 2

		// cara agar hasilnya berkoma,ubah salah satu tipe data nya jadi float
		int d = 10;
		float e = 4;
		float f = d / e;
		System.out.printf("%d / %f = %f\n\n\n",d,e,f);

		// cara supaya tipe data nya tak dirubah
		int x = 10;
		int y = 4;
		float z = (float) x / y;
		System.out.printf("%d / %d = %f \n",x,y,z);
	}
}