import java.util.Arrays;

public class Main{
	public static void main(String[] args) {
		int[] angkaInt = {1,2,3,4,5,6,7,8,9,10};
		angka[0] = 10;
		for(int i = 0; i <= angka.length; i++) {
			System.out.println(angka[i]);
		}

		// Deklarasi Array
		// tipeData[] namaArrayNya = new tipeData[jumlahData];
		int[] angkaFloat= new int[10];
		// cara mengisi datanya
		// angkaFloat[3] = 4;
		angkaFloat[3] = 4.3;

		// keluaarkan
		System.out.println(Arrays.toString(angkaInt));
		System.out.println(Arrays.toString(angkaFloat));




	}
}