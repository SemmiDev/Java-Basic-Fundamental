import java.util.*;

public class Main{
	public static void main(String[] args) {
		Scanner userInput = new Scanner(System.in);

		System.out.print("Masukkan angka : ");
		int input = userInput.nextInt();

		int j = jumlahNilai(input);
		System.out.println("jumlahnya = " + j);
			System.out.println("\n\n");
		int r = faktorial(input);
		System.out.println("rekursifnya = " + r);



	}


	private static int jumlahNilai(int parameter) {
		System.out.println("parameter = " + parameter);
		if(parameter == 0) {
			return parameter;
		}
		return parameter + jumlahNilai(parameter - 1);
	}

	private static int faktorial(int parameter) {
		System.out.println("parameter = " + parameter);
		if(parameter == 1) {
			return parameter;
		}
		return parameter * faktorial(parameter - 1);
	}


}