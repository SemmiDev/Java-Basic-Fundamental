package com.tutorial;

public class Main{
	public static void main(String[] args) {
		int a = 0;
		boolean kondisi = true;
		while (kondisi) {
			System.out.println("while loop ke- " + a);
			if(a == 100) {
				kondisi = false;
			}
			a++;
		}
	}
}