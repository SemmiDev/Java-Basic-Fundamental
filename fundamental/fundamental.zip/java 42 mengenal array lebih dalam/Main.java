// package com.tutorial;
import java.util.Arrays;

public class Main {
	public static void main(String[] args) {
		int arraySatu[] = {1,2,3,4,5,6,7,8,9,10};
		int arrayDua[] = new int[10];
		// print alamat array 1 dan 2c
		System.out.println(arraySatu);
		System.out.println(arrayDua);

		// kita isi array 2 dengan array 1
		arrayDua = arraySatu;

		// print lagi alamat dari kedua array tersebut
		// maka alamat nya akan jadi sama
		System.out.println(arraySatu);
		System.out.println(arrayDua);

		// print isi kedua array tersebut ke console
		System.out.println(Arrays.toString(arraySatu));
		System.out.println(Arrays.toString(arrayDua));

		// coba kita isi arraya nya ke index ke -n dan yagn kedua
		// jika salah satu array yagn telah di berikan operaator assignment maka jika salah satu array diubah nilainya maka,array kedua juga akan ikut berubah

		arraySatu[1] = 100;
		arrayDua[3] = 200;
		System.out.println(Arrays.toString(arraySatu));
		System.out.println(Arrays.toString(arrayDua));

		// kita panggil method nya,dengan niat ingin mengubah nilai dari index nya dari method
		ubahAngka(arraySatu);
		System.out.println(Arrays.toString(arraySatu));
		System.out.println(Arrays.toString(arrayDua));



		// 

	}
	private static void ubahAngka(int dataArray[]){
		dataArray[6] = 1321;
	}
}