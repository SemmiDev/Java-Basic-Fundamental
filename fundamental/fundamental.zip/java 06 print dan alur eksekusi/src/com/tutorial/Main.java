package com.tutorial;

public class Main {
	public static void main(String[] args) {
		System.out.println("Hello World 1");
		System.out.println("Hello World 2");
		System.out.println("Hello World 3");

		System.out.println("Hello World \n");
		System.out.println("Hello World \n");
		System.out.println("Hello World \n");

		System.out.print("Hello ini tanpa adanya newline");
		System.out.print("Hello ini tanpa adanya newline");
		System.out.print("Hello ini tanpa adanya newline");

		System.out.printf("Hello World %d", 1);
		System.out.printf("Hello World %d", 2);
		System.out.printf("Hello World %d", 3);
		
	}
}