// package com.tutorial;

import java.util.Scanner;
import java.io.FileInputStream;
import java.io.IOException;

public class Main{
	public static void main(String[] args) {

		int[] arrayData = {0,1,2,3,4,5};
		Scanner	userInput = new Scanner(System.in);
		FileInputStream fileInput = null;

		System.out.print("Masukkan angka : ");
		int index = userInput.nextInt();

		// EXCEPTIONI BIASA
		System.out.println("EXCEPTION BIASA");
		try{
			System.out.printf("index ke-%d adalah : %d", index, arrayData[index]);
		}catch(ArrayIndexOutOfBoundsException e) {
			System.err.println(e);
		}

		// EXCEPTION DALAM FUNGSI
		System.out.println("\n\nEXCEPTION DALAM FUNGSI");
		int data = ambiDataDariArray(arrayData, index);
		System.out.printf("data dari array ke-%d adalah %d\n\n",index,data);

		// EXCEPTION THROWS BY METHOD
		System.out.println("EXCEPTION THROWS BY METHOD");
		int data2 = 0;
		try{
			data2 = ambilData(arrayData, index);
		}catch(Exception e) {
			System.out.printf("data dari array ke-%d adalah %d\n\n",index, data2);
		}
		

		System.out.println("ini adalah akhir dari program");
	}

	private static int ambilData(int[] array, int index) throws Exception{
		int hasil = array[index];
		return hasil;
	}

	private static int ambiDataDariArray(int[] array, int index) {
		int hasil = 0;
		try{
			hasil = array[index];
		}catch(Exception e) {
			System.err.println(e);
		}

		return hasil;
	}
}