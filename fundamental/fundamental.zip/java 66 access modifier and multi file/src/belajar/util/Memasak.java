package belajar.util;

public class Memasak {
	public static void dagingPublic() {
		System.out.println("belajar:memasak.public");
		dagingPrivate();
	}

	private static void dagingPrivate() {
		System.out.println("belajar:memasak:private");
	}

	static void dagingDefault() {
		System.out.println("belajar:memasak:default");
	}

	protected static void dagingProtected() {
		System.out.println("belajar:memasak:protected");
	}
}