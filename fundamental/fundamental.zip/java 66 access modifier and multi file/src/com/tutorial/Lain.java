package com.tutorial;

public class Lain{

	// bagian ini dapat diakses oleh siapapun
	public static void methodPublic() {
		System.out.println("Lain:public");
		methodPrivate();
	}

	// bagian ini hanya daat diaskes oleh class yang bersangkutan
	private static void methodPrivate() {
		System.out.println("Lain:private");
	}

	// ini hanya dapat diakses oleh class dalam package yang sama
	static void methodDefault() {
		System.out.println("Lain:default");
	}

	// this just can acces by class in the same package
	protected static void methodProtected() {
		System.out.println("Lain:protected");
	}
	
}