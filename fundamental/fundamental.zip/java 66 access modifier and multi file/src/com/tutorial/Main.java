package com.tutorial;
import belajar.util.Memasak;

public class Main{
	public static void main(String[] args) {
		// public, private, default, and protected

		// dengan access modifier public, dapat diakse
		Lain.methodPublic();
		// dengan acces modifier private, tidak dapat diakses
		// Lain.methodPrivate();


		// bisa diakses karena masih dalam package yang sama
		Lain.methodDefault();

		// bisa diakses karena masih dalam package yang sama
		Lain.methodProtected();





		Memasak.dagingPublic();
		// Memasak.dagingPrivate(); // tidak bisa
		// Memasak.dagingDefault(); // tidak bisa
		// Memasak.dagingProtected(); // tidak bisa karena bukan dalam package yg sama

	}
}