// package com.tutorial;

public class Main{
	public static void main(String[] args) {
		String nama = "SamDev";
		int umur = 17;

		System.out.println("nama saya adalah " + nama + ", umur saya adalah " + umur);
		System.out.printf("nama saya adalah %s, umur saya adalah %d",nama,umur);
		// convereion : f=floating point, d=integer, b=boolean, c=character

		// struktur format = %[argumen_index$][flags][width][preision]

		// [argumen_index$]
		System.out.printf("\n [argumen_index$] = ");
		// udin, wahai udin, kemana saja kamu udin
		System.out.printf("%1$s , wahai %1$s, kemana saja kamu %1$s",nama);

		// umur udin berapa? udin menjawab : 17, wah masih muda ya umurnya 17
		System.out.printf("\n umur %1$s berapa? , %1$s menjawab : %2$d, wah masih muda ya umurnya %2$d",nama,umur);

		// [flags]
		int int1 = 5;
		int int2 = 8;
		int hasil = int1 - int2;
		System.out.printf("\n %d -%d = %d \n",int1,int2,hasil);

		// [width]
		int int3 = 1000;
		System.out.printf("%d \n",int3);
		System.out.printf("%5d \n",int3);
		System.out.printf("%-5d \n",int3); // flags "-" artinya rata kiri
		System.out.printf("%+5d \n",int3); // flags akan mengambil slot di dalam format
		System.out.printf("%+-6d \n",int3); // flags bisa digabungkan
		System.out.printf();






		// precision
		float float2 = 15.342f;
		System.out.printf("%f",float2);
		System.out.printf("%.1f",float2); // akan membulatkan menjadi satu di belakang koma
		System.out.printf("%.2f",float2); // akan membulatkan menjadi dua di belakang koma



	}
}