package com.tutorial;
import java.util.*;

public class Main{
	public static void main(String[] args) {
		Scanner inputUser = new Scanner(System.in);
		System.out.println("IF STATEMENT");
		int a = 5;
		int nilaiTebakan;

		System.out.println("masukkan nilai : ");
		nilaiTebakan = inputUser.nextInt();

		if(nilaiTebakan == 5) {
			System.out.println("ini adalah cabang and true");
		}else {
			System.out.print("false");
		}

	}
}