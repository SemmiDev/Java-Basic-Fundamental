public class Main{
	public static void main(String[] args) {
		printAngka(10.2f); // float
		printAngka(50.4d); // double
		printAngka(20); // int
		printAngka(2); // short


		double hasil1 = tambah(5, 100.3);
		printAngka(hasil1);

		double hasil2 = tambah(5.2, 3);
		printAngka(hasil2);

		int hasil3 = tambah(5, 3);
		printAngka(hasil3);


	}


//duas


	private static int tambah(int angkaInt1,int angkaInt2) {
		return angkaInt1 + angkaInt2;
	}
	private static float tambah(int angkaInt1,float angkaFloat2) {
		return angkaInt1 + angkaFloat2;
	}
	private static double tambah(int angkaInt1,double angkaDouble2) {
		return angkaInt1 + angkaDouble2;
	}



	private static float tambah(float angkaFloat1,float angkaFloat2) {
		return angkaFloat1 + angkaFloat2;
	}
	private static float tambah(float angkaFloat1,int angkaInt2) {
		return angkaFloat1 + angkaInt2;
	}
	private static double tambah(float angkaFloat1,double angkaDouble2) {
		return angkaFloat1 + angkaDouble2;
	}



	private static double tambah(double angkaDouble1,double angkaDouble2) {
		return angkaDouble1 + angkaDouble2;
	}
	private static double tambah(double angkaDouble1,int angkaInt2) {
		return angkaDouble1 + angkaInt2;
	}

	private static double tambah(double angkaDouble1,float angkaFloat2) {
		return angkaDouble1 + angkaFloat2;
	}








// tunggal
	private static void printAngka(float angkaFloat) {
		System.out.println("Ini adalah angka " + angkaFloat);
	}

	private static void printAngka(int angkaInt) {
		System.out.println("Ini adalah angka " + angkaInt);
	}

	private static void printAngka(double angkaDouble) {
		System.out.println("Ini adalah angka " + angkaDouble);
	}

	private static void printAngka(short angkaShort) {
		System.out.println("Ini adalah angka " + angkaShort);
	}


}