import java.util.*;

public class Main{
	public static void main(String[] args) {
		int[] arrayAngka1 = {2,3,5,4,1,7,6,9,10,8};
		int[] arrayAngka2 = {13,12,15,16,17,14,19,18,20,11};
		// penjumlahan antar dua buah array
		int[] arrayHasil = tambahArray(arrayAngka1,arrayAngka2);		
		printArray(arrayHasil,"hasil penjumlahan array 1 dengan array yang ditampung di array pertama : ");

		// menggabungkan kedua isi array
		int[] arrayHasil2 = new int[arrayAngka1.length + arrayAngka2.length];
		for(int i = 0; i < arrayAngka1.length; i++) {
			arrayHasil2[i] = arrayAngka1[i]; 
		}
		for(int i = 0; i < arrayAngka2.length; i++) {
			arrayHasil2[i + arrayAngka1.length] = arrayAngka2[i]; 
		}
		printArray(arrayHasil2,"hasil penggabungan array 1 dengan array 2 : ");

 		// me reverse array
		
		

		reverse(arrayHasil2);
		printArray(arrayHasil2, "coba : ");
	}

	public static void reverse(int[] dataArray) {
		Arrays.sort(dataArray);
		int[] buffer = Arrays.copyOf(dataArray,dataArray.length);
		for(int i = 0; i < dataArray.length; i++) {
			dataArray[i] = buffer[(dataArray.length - 1) - i];
		}

	}

	public static int[] tambahArray(int[] arrayInt1, int[] arrayInt2) {
		int[] arrayHasil = new int[arrayInt1.length];
		for(int i = 0; i < arrayInt1.length; i++) {
			arrayHasil[i] = arrayInt1[i] + arrayInt2[i];
		}
		return arrayHasil;
	}

	private static void printArray(int[] dataArray, String message) {
		System.out.print("array " + message + Arrays.toString(dataArray) + "\n");
	}
}