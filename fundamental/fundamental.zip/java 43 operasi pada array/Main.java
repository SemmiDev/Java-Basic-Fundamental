import java.util.Arrays;

public class Main{
	public static void main(String[] args) {
// --------------------------------------------------------------------------------------
		int[] array1 = {1,2,3,4,5};
		// mengubah array menjadi string
		System.out.println("Mengubah array menjadi string \n==========");
		printArray(array1);
// --------------------------------------------------------------------------------------
		System.out.println("mengcopy array \n==========");
		// mengcopy array
		int[] array2 = new int[5];
		printArray(array1);
		printArray(array2); // ini collection nilai didalamnya masih nol
		// mengkopy dengan loop (cara biasa) ----------------------------
		System.out.println("mengcopy array dengan looping for");
		for(int i = 0; i < array1.length; i++) {
			array2[i] = array1[i];
		}
		printArray(array1);
		// alamaat array1
		printAddress(array1);
		printArray(array2);
		// alamaat array2
		printAddress(array2);

		// mengcopy dengan dengan copyOf ----------------------------
		int[] array3 = Arrays.copyOf(array1,5);
		printArray(array3);
		printAddress(array3);

		// copyOfRange = mengkoy array dari index keberapa sampai kemana
		// int[] namaArray = Arrays.copyOfRange(arrayBerapa,from,to)
		// from => dihitung dengan index
		// to => dihitung dengan index lebih 1 "untuk batas mengahirinya"
		int[] array4 = Arrays.copyOfRange(array1,3,5);
		printArray(array4);
		printAddress(array4);

		// mengisi suatu array dengan angka yg sama ----------------------------
		int[] array5 = new int[10];
		printArray(array5);
		// menggunkana => Arrays.fill(nama array yg akan diisi,nilai yg akan dirubah);
		Arrays.fill(array5,1);
		printArray(array5);


// --------------------------------------------------------------------------------------
		// komparasi array
		int[] array6 = {1,2,3,4,5};
		int[] array7 = {1,2,3,4,5};

		
		if(Arrays.equals(array6,array7)){
			System.out.println("array 6 dan 7= sama");
		}else {
				System.out.println("array 6 dan 7= beda");
		}

		// membandingkan array mana array yang lebih besar ----------------------------
		// jika array6 lebih besar daripada array7 maka hasil => 1
		// jika array7 lebih besar daripada array6 maka hasil => -1
		// jika array6 sama besar dengan array7 maka hasil => 0
		System.out.println(Arrays.compare(array6,array7));

		// mmengecek index yang berbeda antara dua array ----------------------------
		// jika output = -1 => semua nilai perindex sama
		// jika ouput nya selain -1 => berarti menunjuk ke index yang berbeda itu
		
		System.out.println(Arrays.mismatch(array6,array7));

// --------------------------------------------------------------------------------------		
		// sort array
		int[] array8 = {4,2,8,7,6,4,5,1,3,8};
		printArray(array8);
		Arrays.sort(array8);
		printArray(array8);

// --------------------------------------------------------------------------------------		
		// search array ke index berapa
		// harus di sorting dulu
		printArray(array8);
		int angkaa = 4;
		int posisi = Arrays.binarySearch(array8,angkaa);
		System.out.println("angka " + angkaa + " berada di index yg ke - " + posisi);
// --------------------------------------------------------------------------------------		

	}

	private static void printArray(int[] dataArray) {
		System.out.println("Array = " + Arrays.toString(dataArray));
	}

	private static void printAddress(int[] dataArray) {
		System.out.println("alamat dari Array = " + dataArray);
	}
}

// tugas = sort kebalik
// operasi tambah antara dua array
// menggabungkan dua buah array
