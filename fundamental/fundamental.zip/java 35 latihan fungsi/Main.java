import java.util.*;

public class Main{
	public static void main(String[] args) {

		Scanner inputUser = new Scanner(System.in);

		System.out.print("Masukkan Panjang : ");
		int panjangUser = inputUser.nextInt();
		System.out.print("Masukkan Lebar : ");
		int lebarUser = inputUser.nextInt();

		gambar(panjangUser,lebarUser);
		System.out.println("luas dari ( P = " + panjangUser + " ) dan ( L = " + lebarUser + " ) adalah => " + luas(panjangUser,lebarUser));
		System.out.println("keliling dari ( P = " + panjangUser + " ) dan ( L = " + lebarUser + " ) adalah => " + keliling(panjangUser,lebarUser));


	}

	private static void gambar(int p,int l) {
		for(int x = 0; x < l; x++) {
			for(int y = 0; y < p; y++) {
				System.out.print("* ");
			}
			System.out.print("\n");
		}
	}

	private static int luas(int p,int l) {
		int hasil;
		hasil = p * l;
		return hasil;
	}

	private static int keliling(int p,int l) {
		int hasil;
		hasil = 2 * (p + l);
		return hasil;
	}


}