// package com.tutorial;
import java.lang.StringBuilder;

public class Main{
	public static void main(String[] args) {
		// String Builder
		StringBuilder builder = new StringBuilder("Hallo");
		printData(builder);

		// append : menambah data di ujung
		builder.append(" semuanya!");
		printData(builder);
		builder.append(" warga talu");
		printData(builder);

		// insert
		builder.insert(26,", pasaman barat");
		printData(builder);

		// delete
		builder.delete(22,26);
		printData(builder);

		// mengubah karakter pada index tertentu
		builder.setCharAt(0,'H');
		builder.setCharAt(1,'E');
		builder.setCharAt(2,'L');
		builder.setCharAt(3,'L');
		builder.setCharAt(4,'O');
		printData(builder);


		// replace
		builder.replace(0,4,"HAI");
		printData(builder);

		// casting menjadi string
		String kalimat = builder.toString();
		System.out.print(kalimat);
		int addressString = System.identityHashCode(kalimat);
		System.out.println("alamat string ==>> " + Integer.toHexString(addressString));





	}

	private static void printData(StringBuilder dataBuilder){
		System.out.println("data  " + dataBuilder);
		System.out.println("data  " + dataBuilder.length());
		// kapasitas default : 16
		System.out.println("data  " + dataBuilder.capacity());

		int addressBuilder = System.identityHashCode(dataBuilder);
		System.out.println("adress : " + Integer.toHexString(addressBuilder));
	}
}