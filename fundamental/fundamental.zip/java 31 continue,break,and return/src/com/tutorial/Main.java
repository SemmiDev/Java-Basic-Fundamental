package com.tutorial;

public class Main{
	public static void main(String[] args) {
		
		int i = 0;
		while(true) {
			i++;

			if(i == 10) {
				break; // berhenti disini dan selanjutnya tidak akan di eksekusi lagi
			}else if(i == 5) {
				continue; // saat i nya bernilai 4, nilai 5 nya akan di skip / tidak dijalankan. lanjut keatas lagi dan lanjut ke 6
			}else if(i == 7) {
				return; 
				// program akan berhenti saat tiba disini, yg selanjutnya tidak akan di eksekusi
			}
		
			System.out.println("this angka ke - " + i);
		}
		System.out.println("AKHIR DARI PROGRAM");
	}
}