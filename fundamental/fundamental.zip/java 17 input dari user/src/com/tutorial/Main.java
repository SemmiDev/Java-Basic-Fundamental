package com.tutorial;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		
		Scanner inputUser = new Scanner(System.in);
		int user, pass;
		int dataUser = 123;
		int dataPass = 123;

		float panjang, lebar, tinggi, luas, volume, keliling;


		System.out.print("input your username : ");
		user = inputUser.nextInt();
		System.out.print("input your password : ");
		pass = inputUser.nextInt();

		if(user == dataUser && pass == dataPass) {
			System.out.println("SELAMAT DATANG DI PROGRAM MENGHITUNG LUAS,VOLUME, DAN KELILING PERSEGI PANJANG");
			System.out.print("Masukkan Panjang : ");
			panjang = inputUser.nextFloat();
			System.out.print("Masukkan lebar : ");
			lebar = inputUser.nextFloat();
			System.out.print("Masukkan tinggi : ");
			tinggi = inputUser.nextFloat();

			luas = panjang * lebar;
			volume = luas * tinggi;
			keliling = 2 * (panjang + lebar); 

			System.out.println("Luas nya adalah : " + luas);
			System.out.println("volume nya adalah : " + volume);
			System.out.println("keliling nya adalah : " + keliling);
		}else {
				System.out.println("USERNAME DAN PASSWORD ANDA SALAH!!!");
		}






		








	}
}