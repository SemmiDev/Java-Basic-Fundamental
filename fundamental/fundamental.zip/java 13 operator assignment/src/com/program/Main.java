package com.program;

public class Main {
	public static void main(String[] args) {
		// operator assignment
		int i = 10;
		i += 10;
		System.out.println("nilai dari i = " + i);

		int a = 100;
		a -= 56;
		System.out.println("nilai dari a = " + a);

		int b = 20;
		b *= 1000;
		System.out.println("nilai dari b = " + b);

		int c = 100;
		c /= 2;
		System.out.println("nilai dari c = " + c);

		int d = 10;
		d %= 7;
		System.out.println("nilai dari d = " + d);
	}
}